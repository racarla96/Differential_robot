# drv8838
Simple Arduino library for the TI DRV8838 motor driver

Use this library at your own risk/peril.  I assume no liability for anything this code gets used for.
